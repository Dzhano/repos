﻿using System;
using System.Collections.Generic;

namespace BorderControl
{
    class Program
    {
        static void Main(string[] args)
        {
            /* 04. Border Control
            List<IId> ids = new List<IId>();
            string input = string.Empty;
            while ((input = Console.ReadLine()) != "End")
            {
                string[] data = input.Split(" ", StringSplitOptions.RemoveEmptyEntries);
                if (data.Length == 3)
                {
                    int citizenAge = int.Parse(data[1]);
                    Citizen newCitizen = new Citizen(data[0], citizenAge, data[2]);
                    ids.Add(newCitizen);
                }
                else if (data.Length == 2)
                {
                    Robot newRobot = new Robot(data[0], data[1]);
                    ids.Add(newRobot);
                }
            }

            string fakeID = Console.ReadLine();
            foreach (var item in ids) 
                if (item.Id.EndsWith(fakeID)) 
                    Console.WriteLine(item.Id);*/

            // 05. Birthday Celebrations
            List<IBirthdate> birthdates = new List<IBirthdate>();
            string input = string.Empty;
            while ((input = Console.ReadLine()) != "End")
            {
                string[] data = input.Split(" ", StringSplitOptions.RemoveEmptyEntries);
                if (data[0] == "Citizen")
                {
                    int citizenAge = int.Parse(data[2]);
                    Citizen newCitizen = new Citizen(data[1], citizenAge, data[3], data[4]);
                    birthdates.Add(newCitizen);
                }
                else if (data[0] == "Pet")
                {
                    Pet newPet = new Pet(data[1], data[2]);
                    birthdates.Add(newPet);
                }
                else if (data[0] == "Robot") continue;
            }

            string year = Console.ReadLine();
            foreach (var item in birthdates)
                if (item.Birthdate.EndsWith(year))
                    Console.WriteLine(item.Birthdate);
        }
    }
}
