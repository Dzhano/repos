﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    public interface ICalling
    {
        void Calling(string phoneNumber);
    }
}
