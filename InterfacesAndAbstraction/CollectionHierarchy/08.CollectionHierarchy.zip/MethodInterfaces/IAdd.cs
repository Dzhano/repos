﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CollectionHierarchy.MethodInterfaces
{
    public interface IAdd
    {
        int Add(string element);
    }
}
