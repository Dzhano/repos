﻿using System;
using System.Collections.Generic;

namespace ListyIterator
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] data = Console.ReadLine().Split();
            List<string> elements = new List<string>();
            for (int i = 1; i < data.Length; i++)
                elements.Add(data[i]);
            ListyIterator<string> listyIterator = new ListyIterator<string>(elements);
            string command = string.Empty;
            while ((command = Console.ReadLine()) != "END")
            {
                switch (command)
                {
                    case "Move":
                        Console.WriteLine(listyIterator.Move());
                        break;
                    case "Print":
                        listyIterator.Print();
                        break;
                    case "HasNext":
                        Console.WriteLine(listyIterator.HasNext());
                        break;
                }
            }
        }
    }
}
