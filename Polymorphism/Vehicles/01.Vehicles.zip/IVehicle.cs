﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public interface IVehicle
    {
        void Driving(double distance);
        void Refueling(double fuelLiters);
    }
}
