﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public class Truck : IVehicle
    {
        private double fuelQuantity;
        public double FuelQuantity
        {
            get => fuelQuantity;
            private set => fuelQuantity = value;
        }
        private double litersPerKm;

        public Truck(double fuelQuantity, double litersPerKm)
        {
            this.FuelQuantity = fuelQuantity;
            this.litersPerKm = litersPerKm + 1.6;
        }

        public void Driving(double distance)
        {
            double result = FuelQuantity - (distance * litersPerKm);
            if (result >= 0)
            {
                FuelQuantity -= distance * litersPerKm;
                Console.WriteLine($"Truck travelled {distance} km");
            }
            else Console.WriteLine($"Truck needs refueling");
        }

        public void Refueling(double fuelLiters)
        {
            FuelQuantity += fuelLiters * 0.95;
        }
    }
}
