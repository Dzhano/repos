﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public class Car : IVehicle
    {
        private double fuelQuantity;
        public double FuelQuantity
        {
            get => fuelQuantity;
            private set => fuelQuantity = value;
        }
        private double litersPerKm;

        public Car(double fuelQuantity, double litersPerKm)
        {
            this.FuelQuantity = fuelQuantity;
            this.litersPerKm = litersPerKm + 0.9;
        }

        public void Driving(double distance)
        {
            double result = FuelQuantity - (distance * litersPerKm);
            if (result >= 0)
            {
                FuelQuantity -= distance * litersPerKm;
                Console.WriteLine($"Car travelled {distance} km");
            }
            else Console.WriteLine($"Car needs refueling");
        }

        public void Refueling(double fuelLiters)
        {
            FuelQuantity += fuelLiters;
        }
    }
}
