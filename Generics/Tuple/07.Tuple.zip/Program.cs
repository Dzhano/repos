﻿using System;

namespace Tuple
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] data = Console.ReadLine().Split(" ");
            CustomTuple<string, string> tupleOne = new CustomTuple<string, string>($"{data[0]} {data[1]}", data[2]);

            string[] data2 = Console.ReadLine().Split(" ");
            CustomTuple<string, int> tupleTwo = new CustomTuple<string, int>(data2[0], int.Parse(data2[1]));

            string[] data3 = Console.ReadLine().Split(" ");
            CustomTuple<int, double> tupleThree = new CustomTuple<int, double>(int.Parse(data3[0]), double.Parse(data3[1]));

            Console.WriteLine(tupleOne.ToString());
            Console.WriteLine(tupleTwo.ToString());
            Console.WriteLine(tupleThree.ToString());
        }
    }
}
