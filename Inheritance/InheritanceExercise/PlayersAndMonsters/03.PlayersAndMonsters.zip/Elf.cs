﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlayersAndMonsters
{
    public class Elf : Hero
    {
        public Elf(string usermame, int level)
            : base(usermame, level)
        {

        }
    }
}
