﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlayersAndMonsters
{
    public class Wizard : Hero
    {
        public Wizard(string usermame, int level)
            : base(usermame, level)
        {

        }
    }
}
