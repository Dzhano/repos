﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlayersAndMonsters
{
    public class MuseElf : Elf
    {
        public MuseElf(string usermame, int level)
            : base(usermame, level)
        {

        }
    }
}
