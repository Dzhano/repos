﻿using System;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Car car = new Car();
            car.Make = "Ford";
            car.Model = "S-Max";
            car.Year = 2019;
            car.FuelQuantity = 200;
            car.FuelConsumption = 50;
            car.Drive(2);

            Console.WriteLine(car.WhoAmI());
        }
    }
}
